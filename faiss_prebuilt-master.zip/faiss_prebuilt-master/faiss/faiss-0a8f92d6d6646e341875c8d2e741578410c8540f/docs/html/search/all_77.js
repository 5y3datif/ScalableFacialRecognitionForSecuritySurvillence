var searchData=
[
  ['waitforthreadexit',['waitForThreadExit',['../classfaiss_1_1gpu_1_1WorkerThread.html#aa7fd80a803f543a2027ea74e81db677a',1,'faiss::gpu::WorkerThread']]],
  ['warpselect',['WarpSelect',['../structfaiss_1_1gpu_1_1WarpSelect.html',1,'faiss::gpu']]],
  ['warpselect_3c_20k_2c_20v_2c_20dir_2c_20comp_2c_201_2c_20numthreadq_2c_20threadsperblock_20_3e',['WarpSelect&lt; K, V, Dir, Comp, 1, NumThreadQ, ThreadsPerBlock &gt;',['../structfaiss_1_1gpu_1_1WarpSelect_3_01K_00_01V_00_01Dir_00_01Comp_00_011_00_01NumThreadQ_00_01ThreadsPerBlock_01_4.html',1,'faiss::gpu']]],
  ['weights',['weights',['../structfaiss_1_1ReproduceDistancesObjective.html#a982332b44ff32b9ae9694e374acd0aff',1,'faiss::ReproduceDistancesObjective']]],
  ['what',['what',['../classfaiss_1_1FaissException.html#ab75086632bbd1b8e13f002c8942a7672',1,'faiss::FaissException']]],
  ['workerthread',['WorkerThread',['../classfaiss_1_1gpu_1_1WorkerThread.html',1,'faiss::gpu']]],
  ['wp',['wp',['../structfaiss_1_1BufferList.html#af4d7ddcd77f328a12a7da89d8febe5d9',1,'faiss::BufferList']]],
  ['writeout',['writeOut',['../structfaiss_1_1gpu_1_1WarpSelect.html#a1cd82964e633531a95d5d095e012acb5',1,'faiss::gpu::WarpSelect::writeOut()'],['../structfaiss_1_1gpu_1_1WarpSelect_3_01K_00_01V_00_01Dir_00_01Comp_00_011_00_01NumThreadQ_00_01ThreadsPerBlock_01_4.html#a65f05abb17750d13bd9e03d56cd86fd2',1,'faiss::gpu::WarpSelect&lt; K, V, Dir, Comp, 1, NumThreadQ, ThreadsPerBlock &gt;::writeOut()']]]
];
