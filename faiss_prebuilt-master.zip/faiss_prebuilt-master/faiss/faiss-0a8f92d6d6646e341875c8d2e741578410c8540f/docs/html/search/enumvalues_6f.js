var searchData=
[
  ['ot_5franking_5fweighted_5fdiff',['OT_Ranking_weighted_diff',['../structfaiss_1_1PolysemousTraining.html#aeb5a523056697934972f95fd428f61efa514d33b85a240091cdd7b8efaf66a0b5',1,'faiss::PolysemousTraining']]],
  ['ot_5freproducedistances_5faffine',['OT_ReproduceDistances_affine',['../structfaiss_1_1PolysemousTraining.html#aeb5a523056697934972f95fd428f61efa4f1f59a0027c1662a7aaf66f2a78fb23',1,'faiss::PolysemousTraining']]]
];
