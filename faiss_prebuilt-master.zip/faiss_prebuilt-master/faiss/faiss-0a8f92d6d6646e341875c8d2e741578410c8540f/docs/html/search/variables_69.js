var searchData=
[
  ['id_5fmap',['id_map',['../structfaiss_1_1IndexIDMap.html#ad1cc5658f1879f6a2b00d76cca58cf3b',1,'faiss::IndexIDMap']]],
  ['ids',['ids',['../structfaiss_1_1HeapArray.html#a22332dd179ce70e379addeaa47246cc2',1,'faiss::HeapArray::ids()'],['../structfaiss_1_1ArrayInvertedLists.html#a48563a58d3bbfbb4334f3afdf2c9ba7a',1,'faiss::ArrayInvertedLists::ids()']]],
  ['ils',['ils',['../structfaiss_1_1ivflib_1_1SlidingIndexWindow.html#a10d876a9c750bc95986a22a57cf4fdc7',1,'faiss::ivflib::SlidingIndexWindow']]],
  ['index',['index',['../structfaiss_1_1ivflib_1_1SlidingIndexWindow.html#a2aae96a9373173e22686951e85b31aa1',1,'faiss::ivflib::SlidingIndexWindow::index()'],['../structfaiss_1_1IndexPreTransform.html#aee3cbbe7915ec9ed13d59ca9276bdefc',1,'faiss::IndexPreTransform::index()']]],
  ['indicesoptions',['indicesOptions',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#ad960ac51b7cc607fcb1a1b07efc32a9e',1,'faiss::gpu::GpuClonerOptions::indicesOptions()'],['../structfaiss_1_1gpu_1_1GpuIndexIVFConfig.html#af432221761d48e4753f501208a60264d',1,'faiss::gpu::GpuIndexIVFConfig::indicesOptions()']]],
  ['indicesoptions_5f',['indicesOptions_',['../classfaiss_1_1gpu_1_1IVFBase.html#afb6d10e23d6448c10f472b9234e0bcab',1,'faiss::gpu::IVFBase']]],
  ['init_5fcost',['init_cost',['../structfaiss_1_1SimulatedAnnealingOptimizer.html#aa8ff19f97482c6213b2a8ff3b190412b',1,'faiss::SimulatedAnnealingOptimizer']]],
  ['instances',['instances',['../structfaiss_1_1IndexIVFFlatDedup.html#a1ff220494d504dd806e5daf290ec0e7a',1,'faiss::IndexIVFFlatDedup']]],
  ['invlists',['invlists',['../structfaiss_1_1IndexBinaryIVF.html#a094ef9572645ff86a76ff4df967bf65a',1,'faiss::IndexBinaryIVF::invlists()'],['../structfaiss_1_1IndexIVF.html#aa0e8fc5e04cbd8e0dde61f98bc7dd0bc',1,'faiss::IndexIVF::invlists()']]],
  ['is_5forthonormal',['is_orthonormal',['../structfaiss_1_1LinearTransform.html#a8a67a0178eab513cf87545f5d12d9569',1,'faiss::LinearTransform']]],
  ['is_5ftrained',['is_trained',['../structfaiss_1_1Index.html#a6e92732617c4dbe364e7678dd8773a7f',1,'faiss::Index::is_trained()'],['../structfaiss_1_1IndexBinary.html#a132119ae93e240b54621c5c669853c7f',1,'faiss::IndexBinary::is_trained()'],['../structfaiss_1_1VectorTransform.html#ab511f1ddf608c00204555881ca28cb02',1,'faiss::VectorTransform::is_trained()']]],
  ['isowner_5f',['isOwner_',['../structfaiss_1_1gpu_1_1StackDeviceMemory_1_1Stack.html#a949014db795e0def2c257aa775993230',1,'faiss::gpu::StackDeviceMemory::Stack']]]
];
