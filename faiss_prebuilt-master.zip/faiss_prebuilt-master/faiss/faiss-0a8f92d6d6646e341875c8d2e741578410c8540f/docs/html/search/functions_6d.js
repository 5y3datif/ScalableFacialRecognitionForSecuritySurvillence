var searchData=
[
  ['make_5fdirect_5fmap',['make_direct_map',['../structfaiss_1_1IndexBinaryIVF.html#a280d0a3958664c3eb4164fcb62496b00',1,'faiss::IndexBinaryIVF::make_direct_map()'],['../structfaiss_1_1IndexIVF.html#a1c11ce77f459e2ab3e5d9a4c2263ad89',1,'faiss::IndexIVF::make_direct_map()']]],
  ['matrix_5fqr',['matrix_qr',['../namespacefaiss.html#afb68fe89ad5e948974da1b70d7b4157c',1,'faiss']]],
  ['maxdiff',['maxDiff',['../classfaiss_1_1gpu_1_1HostTensor.html#a4f8c1a0467513d62277b693dd65238c5',1,'faiss::gpu::HostTensor']]],
  ['merge_5ffrom',['merge_from',['../structfaiss_1_1IndexBinaryIVF.html#a5296e62b0524f13ff66c61fb7db499a2',1,'faiss::IndexBinaryIVF::merge_from()'],['../structfaiss_1_1IndexIVF.html#a0f22cc237c30c935df5b6560aecf8f01',1,'faiss::IndexIVF::merge_from()'],['../structfaiss_1_1IndexIVFPQR.html#a31a1fec2a88b410ea96ce5be7d527be9',1,'faiss::IndexIVFPQR::merge_from()'],['../structfaiss_1_1InvertedLists.html#ac2a0686121ef5bdd6eb70f7eb3cf9b3a',1,'faiss::InvertedLists::merge_from()']]],
  ['merge_5fresult_5ftable_5fwith',['merge_result_table_with',['../namespacefaiss.html#afb7b33f6892678ba79aaf5e71777837c',1,'faiss']]],
  ['merge_5fwith',['merge_with',['../structfaiss_1_1OperatingPoints.html#a84baddccd8b803dee460739f8bcbc0c9',1,'faiss::OperatingPoints']]],
  ['mergewarpq',['mergeWarpQ',['../structfaiss_1_1gpu_1_1BlockSelect.html#a08aa08d16ec29c7b7dccc65edd5115cd',1,'faiss::gpu::BlockSelect::mergeWarpQ()'],['../structfaiss_1_1gpu_1_1WarpSelect.html#a408cbf9a09094078cb62018400f30076',1,'faiss::gpu::WarpSelect::mergeWarpQ()']]],
  ['multiindexquantizer',['MultiIndexQuantizer',['../structfaiss_1_1MultiIndexQuantizer.html#a01a568055ebc1e841f7e4218722efa01',1,'faiss::MultiIndexQuantizer']]]
];
