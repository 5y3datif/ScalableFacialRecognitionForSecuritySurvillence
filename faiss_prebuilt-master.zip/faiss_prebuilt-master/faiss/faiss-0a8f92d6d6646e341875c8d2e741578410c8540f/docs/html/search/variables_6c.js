var searchData=
[
  ['labels',['labels',['../structfaiss_1_1RangeSearchResult.html#aa8ff848474a4cc16c5464cc4ec187824',1,'faiss::RangeSearchResult']]],
  ['lastusers_5f',['lastUsers_',['../structfaiss_1_1gpu_1_1StackDeviceMemory_1_1Stack.html#a9fc42fbbe671faee41ea85a68bdb6b1e',1,'faiss::gpu::StackDeviceMemory::Stack']]],
  ['levels',['levels',['../structfaiss_1_1HNSW.html#a44847954c98957404829182c7db1b8af',1,'faiss::HNSW']]],
  ['lims',['lims',['../structfaiss_1_1RangeSearchResult.html#aef57f9db99ca470c01bcdce0366cb6ff',1,'faiss::RangeSearchResult']]],
  ['listoffsettouserindex_5f',['listOffsetToUserIndex_',['../classfaiss_1_1gpu_1_1IVFBase.html#a53f3c382a79b7f89630a85dfbc3a1fed',1,'faiss::gpu::IVFBase']]]
];
