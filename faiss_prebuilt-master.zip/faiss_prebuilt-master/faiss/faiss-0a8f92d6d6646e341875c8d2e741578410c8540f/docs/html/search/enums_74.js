var searchData=
[
  ['train_5ftype_5ft',['train_type_t',['../structfaiss_1_1ProductQuantizer.html#a3a41c6286095e731be744548d9535a35',1,'faiss::ProductQuantizer']]]
];
