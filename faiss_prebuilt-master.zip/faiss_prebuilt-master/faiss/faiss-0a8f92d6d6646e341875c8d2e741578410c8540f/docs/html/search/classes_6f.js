var searchData=
[
  ['ondiskinvertedlists',['OnDiskInvertedLists',['../structfaiss_1_1OnDiskInvertedLists.html',1,'faiss']]],
  ['onerecallatrcriterion',['OneRecallAtRCriterion',['../structfaiss_1_1OneRecallAtRCriterion.html',1,'faiss']]],
  ['ongoingprefetch',['OngoingPrefetch',['../structfaiss_1_1OnDiskInvertedLists_1_1OngoingPrefetch.html',1,'faiss::OnDiskInvertedLists']]],
  ['operatingpoint',['OperatingPoint',['../structfaiss_1_1OperatingPoint.html',1,'faiss']]],
  ['operatingpoints',['OperatingPoints',['../structfaiss_1_1OperatingPoints.html',1,'faiss']]],
  ['opqmatrix',['OPQMatrix',['../structfaiss_1_1OPQMatrix.html',1,'faiss']]],
  ['options',['Options',['../structOptions.html',1,'']]]
];
