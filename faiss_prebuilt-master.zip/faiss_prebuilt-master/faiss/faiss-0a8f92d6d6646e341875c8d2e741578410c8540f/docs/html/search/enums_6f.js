var searchData=
[
  ['optimization_5ftype_5ft',['Optimization_type_t',['../structfaiss_1_1PolysemousTraining.html#aeb5a523056697934972f95fd428f61ef',1,'faiss::PolysemousTraining']]]
];
