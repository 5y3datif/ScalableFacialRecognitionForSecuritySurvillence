var searchData=
[
  ['xb',['xb',['../structfaiss_1_1IndexBinaryFlat.html#afc0b5b076b35a1a1889b0012848c795c',1,'faiss::IndexBinaryFlat::xb()'],['../structfaiss_1_1IndexFlat.html#a9001de47890fe5d2eced9551d3613d47',1,'faiss::IndexFlat::xb()']]]
];
