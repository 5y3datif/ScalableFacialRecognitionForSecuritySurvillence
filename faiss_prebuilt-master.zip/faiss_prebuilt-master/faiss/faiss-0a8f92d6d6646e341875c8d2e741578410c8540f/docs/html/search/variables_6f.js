var searchData=
[
  ['obj',['obj',['../structfaiss_1_1Clustering.html#a91e32da946477bb751706a68c5cd3327',1,'faiss::Clustering']]],
  ['offsets',['offsets',['../structfaiss_1_1HNSW.html#a0b456c521194903b29ce7c157539d771',1,'faiss::HNSW']]],
  ['optimal_5fpts',['optimal_pts',['../structfaiss_1_1OperatingPoints.html#a2829e78e01cc42c3a341622947663b31',1,'faiss::OperatingPoints']]],
  ['own_5ffields',['own_fields',['../structfaiss_1_1IndexBinaryFromFloat.html#a7311fc4d11169f7bc668c16b027336ba',1,'faiss::IndexBinaryFromFloat::own_fields()'],['../structfaiss_1_1IndexBinaryIVF.html#a2c7bc3be67d829d49ac1ab2afc4f6b0c',1,'faiss::IndexBinaryIVF::own_fields()'],['../structfaiss_1_1IndexRefineFlat.html#aaf0f6a094de0e9409effa81bedb9c7e2',1,'faiss::IndexRefineFlat::own_fields()'],['../structfaiss_1_1Level1Quantizer.html#ab688c629cd42122d73517078b87f483d',1,'faiss::Level1Quantizer::own_fields()'],['../structfaiss_1_1IndexIDMap.html#affa8a764304410c96489c2b2e178bcdb',1,'faiss::IndexIDMap::own_fields()'],['../structfaiss_1_1IndexPreTransform.html#ae5ec3f184eb211e7d6e204082b52c8c0',1,'faiss::IndexPreTransform::own_fields()']]]
];
