var searchData=
[
  ['quantizertype',['QuantizerType',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952e',1,'faiss::ScalarQuantizer']]]
];
