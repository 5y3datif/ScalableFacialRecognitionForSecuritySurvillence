var searchData=
[
  ['flatconfig',['flatConfig',['../structfaiss_1_1gpu_1_1GpuIndexIVFConfig.html#a6d357a9a67a2fed9c8e7b139712d30f6',1,'faiss::gpu::GpuIndexIVFConfig']]],
  ['frozen_5fcentroids',['frozen_centroids',['../structFaissClusteringParameters.html#a1caad79e8c8fde45bbc63c7c6da303f1',1,'FaissClusteringParameters::frozen_centroids()'],['../structfaiss_1_1ClusteringParameters.html#ad142063e035f2a0414233f9711e16215',1,'faiss::ClusteringParameters::frozen_centroids()']]]
];
