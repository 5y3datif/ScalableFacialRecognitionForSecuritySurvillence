var searchData=
[
  ['zero',['zero',['../classfaiss_1_1gpu_1_1DeviceTensor.html#a6793f5bd0493b47693369670b1b02591',1,'faiss::gpu::DeviceTensor::zero()'],['../classfaiss_1_1gpu_1_1HostTensor.html#afb34d344157ea0905d2d76d4081da052',1,'faiss::gpu::HostTensor::zero()']]]
];
