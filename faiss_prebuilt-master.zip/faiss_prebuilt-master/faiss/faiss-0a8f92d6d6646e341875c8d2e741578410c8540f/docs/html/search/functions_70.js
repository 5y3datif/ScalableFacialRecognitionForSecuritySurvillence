var searchData=
[
  ['pairwise_5fl2sqr',['pairwise_L2sqr',['../namespacefaiss.html#a3d9c7db82d43c1f0ab1d28b92bc9fe57',1,'faiss']]],
  ['per_5fline_5fextrema',['per_line_extrema',['../structfaiss_1_1HeapArray.html#ab1beefd73c023168c23d5443ee71e369',1,'faiss::HeapArray']]],
  ['precompute_5ftable',['precompute_table',['../structfaiss_1_1IndexIVFPQ.html#ad99c215aeaf92e995cb97f4044c4d267',1,'faiss::IndexIVFPQ']]],
  ['prefetch_5flists',['prefetch_lists',['../structfaiss_1_1InvertedLists.html#a4e62994e54a0834f130bb4ba09c16a9c',1,'faiss::InvertedLists::prefetch_lists()'],['../structfaiss_1_1OnDiskInvertedLists.html#aed1cdb979275ec1e6ab8f0c7fead60c7',1,'faiss::OnDiskInvertedLists::prefetch_lists()']]],
  ['prepare_5fab',['prepare_Ab',['../structfaiss_1_1PCAMatrix.html#a117a70b8fca6d125725fe49fddebf97b',1,'faiss::PCAMatrix']]],
  ['print_5fstats',['print_stats',['../structfaiss_1_1IndexBinaryIVF.html#a992a27940818d1881a662f2f5acd2783',1,'faiss::IndexBinaryIVF::print_stats()'],['../structfaiss_1_1IndexIVF.html#a513dfec3a250f08a9fdd18a24178e6bb',1,'faiss::IndexIVF::print_stats()']]]
];
