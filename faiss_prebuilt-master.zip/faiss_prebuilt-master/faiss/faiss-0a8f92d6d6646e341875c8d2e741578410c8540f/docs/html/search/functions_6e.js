var searchData=
[
  ['n_5fcombinations',['n_combinations',['../structfaiss_1_1ParameterSpace.html#a488329e3c1f08b9980d8e0f9c1491c75',1,'faiss::ParameterSpace']]],
  ['narrow',['narrow',['../classfaiss_1_1gpu_1_1Tensor.html#ab6db6bf86dd0f7e877af3a6ae2100fe3',1,'faiss::gpu::Tensor']]],
  ['narrowoutermost',['narrowOutermost',['../classfaiss_1_1gpu_1_1Tensor.html#ac2d0fc7199901a8e0788b58f0970b133',1,'faiss::gpu::Tensor']]],
  ['nb_5fneighbors',['nb_neighbors',['../structfaiss_1_1HNSW.html#ad497ea80f352c33242ba7835370c2dba',1,'faiss::HNSW']]],
  ['neighbor_5frange',['neighbor_range',['../structfaiss_1_1HNSW.html#aa3ae6a80d358e59e3af23f918253f61d',1,'faiss::HNSW']]],
  ['new_5fresult',['new_result',['../structfaiss_1_1RangeSearchPartialResult.html#a954c26beebb561a6c2b0f399c48a9db3',1,'faiss::RangeSearchPartialResult']]],
  ['notempmemory',['noTempMemory',['../classfaiss_1_1gpu_1_1StandardGpuResources.html#a6431477a7328ac147797b3b4e3fcf651',1,'faiss::gpu::StandardGpuResources']]],
  ['numelements',['numElements',['../classfaiss_1_1gpu_1_1Tensor.html#a0ba9ab7c1676b7a41a6e6b2e5a490d2f',1,'faiss::gpu::Tensor']]]
];
