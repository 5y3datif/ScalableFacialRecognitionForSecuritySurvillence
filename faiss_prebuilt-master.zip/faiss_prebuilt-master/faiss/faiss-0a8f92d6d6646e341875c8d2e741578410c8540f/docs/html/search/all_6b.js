var searchData=
[
  ['k',['k',['../structfaiss_1_1Clustering.html#a87581785d9516c683bbc7c9392bfa993',1,'faiss::Clustering::k()'],['../structfaiss_1_1HeapArray.html#a1ee98429c766c77235f78c6d9aa32bb4',1,'faiss::HeapArray::k()']]],
  ['k_5ffactor',['k_factor',['../structfaiss_1_1IndexRefineFlat.html#a7383fabb28db5b0df45ca4ea81f7acd4',1,'faiss::IndexRefineFlat::k_factor()'],['../structfaiss_1_1IndexIVFPQR.html#a0b02a4151ceacc070352f8b15cc0ee0b',1,'faiss::IndexIVFPQR::k_factor()']]],
  ['kerneltimer',['KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html',1,'faiss::gpu']]],
  ['kerneltimer',['KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html#af533a5a8734243263032960c2445d233',1,'faiss::gpu::KernelTimer']]],
  ['key',['key',['../structfaiss_1_1OperatingPoint.html#aa13782d6d26168531764cb64da941ced',1,'faiss::OperatingPoint']]],
  ['km_5fupdate_5fcentroids',['km_update_centroids',['../namespacefaiss.html#aa2c6a9e87a64bba8e8014e14f70bde21',1,'faiss']]],
  ['kmeans_5fclustering',['kmeans_clustering',['../namespacefaiss.html#a38bd0dde8a1b229201a5fcb64d05daa6',1,'faiss']]],
  ['knn_5finner_5fproduct',['knn_inner_product',['../namespacefaiss.html#a880c7318971f866267a86945aaa61b17',1,'faiss']]],
  ['knn_5fl2sqr',['knn_L2sqr',['../namespacefaiss.html#a2f803e3d3b07cfab63699c89de161237',1,'faiss']]],
  ['knn_5fl2sqr_5fbase_5fshift',['knn_L2sqr_base_shift',['../namespacefaiss.html#a5eb1701e46123827966f2a56da893d1d',1,'faiss']]],
  ['ksub',['ksub',['../structfaiss_1_1ProductQuantizer.html#a0feee45e4151547b7a0444c14bad398f',1,'faiss::ProductQuantizer']]]
];
