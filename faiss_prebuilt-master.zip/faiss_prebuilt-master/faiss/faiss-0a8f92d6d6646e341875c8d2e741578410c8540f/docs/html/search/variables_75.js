var searchData=
[
  ['update_5findex',['update_index',['../structFaissClusteringParameters.html#a1764fa98f759b20fde75abbb2616f844',1,'FaissClusteringParameters::update_index()'],['../structfaiss_1_1ClusteringParameters.html#a27d6192097920fa981cff0acedfaac91',1,'faiss::ClusteringParameters::update_index()']]],
  ['upper_5fbeam',['upper_beam',['../structfaiss_1_1HNSW.html#a857bef0db2dc0000f312cc8a95f857b2',1,'faiss::HNSW']]],
  ['use_5fheap',['use_heap',['../structfaiss_1_1IndexBinaryFlat.html#a9fa80e22a4accee4da0ee152a4910c1b',1,'faiss::IndexBinaryFlat::use_heap()'],['../structfaiss_1_1IndexBinaryIVF.html#abcab702ebe1814ff432401bfd39df492',1,'faiss::IndexBinaryIVF::use_heap()']]],
  ['use_5fprecomputed_5ftable',['use_precomputed_table',['../structfaiss_1_1IndexIVFPQ.html#a1c66ff073c18a1edbe8444c24d870583',1,'faiss::IndexIVFPQ']]],
  ['usefloat16',['useFloat16',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#ac7cc57d6091d6a79ea6020bf8d1fbe27',1,'faiss::gpu::GpuClonerOptions::useFloat16()'],['../structfaiss_1_1gpu_1_1GpuIndexFlatConfig.html#afd694186c87751937a646f3db2c8ba3d',1,'faiss::gpu::GpuIndexFlatConfig::useFloat16()']]],
  ['usefloat16accumulator',['useFloat16Accumulator',['../structfaiss_1_1gpu_1_1GpuIndexFlatConfig.html#a5a2d8737f4277e55fc1a99ef4fc4c630',1,'faiss::gpu::GpuIndexFlatConfig']]],
  ['usefloat16coarsequantizer',['useFloat16CoarseQuantizer',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#a85f3093908b6e9a503c24bb226b17b1b',1,'faiss::gpu::GpuClonerOptions']]],
  ['usefloat16ivfstorage',['useFloat16IVFStorage',['../structfaiss_1_1gpu_1_1GpuIndexIVFFlatConfig.html#ab98ac354bcd5632976f7edc2deda6e57',1,'faiss::gpu::GpuIndexIVFFlatConfig']]],
  ['usefloat16lookuptables',['useFloat16LookupTables',['../structfaiss_1_1gpu_1_1GpuIndexIVFPQConfig.html#a9dbbec78d77d90b7b150f543e477cc49',1,'faiss::gpu::GpuIndexIVFPQConfig']]],
  ['useprecomputed',['usePrecomputed',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#abc9c607f2dfc9f23942a523fb49c63fe',1,'faiss::gpu::GpuClonerOptions']]],
  ['useprecomputedtables',['usePrecomputedTables',['../structfaiss_1_1gpu_1_1GpuIndexIVFPQConfig.html#ae5b5c7acc06743e5bcca197bc33c30ec',1,'faiss::gpu::GpuIndexIVFPQConfig']]]
];
