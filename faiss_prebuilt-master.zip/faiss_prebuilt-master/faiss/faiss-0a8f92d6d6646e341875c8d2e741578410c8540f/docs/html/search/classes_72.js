var searchData=
[
  ['randomgenerator',['RandomGenerator',['../structfaiss_1_1RandomGenerator.html',1,'faiss']]],
  ['randomrotationmatrix',['RandomRotationMatrix',['../structfaiss_1_1RandomRotationMatrix.html',1,'faiss']]],
  ['range',['Range',['../structfaiss_1_1gpu_1_1StackDeviceMemory_1_1Range.html',1,'faiss::gpu::StackDeviceMemory']]],
  ['rangesearchpartialresult',['RangeSearchPartialResult',['../structfaiss_1_1RangeSearchPartialResult.html',1,'faiss']]],
  ['rangesearchresult',['RangeSearchResult',['../structfaiss_1_1RangeSearchResult.html',1,'faiss']]],
  ['rankingscore2',['RankingScore2',['../structfaiss_1_1RankingScore2.html',1,'faiss']]],
  ['reconstructfromneighbors',['ReconstructFromNeighbors',['../structfaiss_1_1ReconstructFromNeighbors.html',1,'faiss']]],
  ['remapdimensionstransform',['RemapDimensionsTransform',['../structfaiss_1_1RemapDimensionsTransform.html',1,'faiss']]],
  ['reproducedistancesobjective',['ReproduceDistancesObjective',['../structfaiss_1_1ReproduceDistancesObjective.html',1,'faiss']]],
  ['restrictptrtraits',['RestrictPtrTraits',['../structfaiss_1_1gpu_1_1traits_1_1RestrictPtrTraits.html',1,'faiss::gpu::traits']]]
];
