var searchData=
[
  ['random_5frotation',['random_rotation',['../structfaiss_1_1PCAMatrix.html#af111f055b7571703a3aa270d89e99321',1,'faiss::PCAMatrix']]],
  ['refine_5fcodes',['refine_codes',['../structfaiss_1_1IndexIVFPQR.html#a588bd0b733c8db18eaeb7bc287afd16e',1,'faiss::IndexIVFPQR']]],
  ['refine_5findex',['refine_index',['../structfaiss_1_1IndexRefineFlat.html#aab99f32713ece942ccefccf306292ca0',1,'faiss::IndexRefineFlat']]],
  ['refine_5fpq',['refine_pq',['../structfaiss_1_1IndexIVFPQR.html#a4a80540e7cdfb3e43712ffb93e083a7c',1,'faiss::IndexIVFPQR']]],
  ['reservevecs',['reserveVecs',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#ab60dd87e51af59373a48d73852573f04',1,'faiss::gpu::GpuClonerOptions']]],
  ['resources_5f',['resources_',['../classfaiss_1_1gpu_1_1GpuIndex.html#a17b82a8a11783da6eb1b07c9aab98c36',1,'faiss::gpu::GpuIndex::resources_()'],['../classfaiss_1_1gpu_1_1GpuIndexBinaryFlat.html#ac3cead0aa496ebe1a46f26a58e566f48',1,'faiss::gpu::GpuIndexBinaryFlat::resources_()'],['../classfaiss_1_1gpu_1_1IVFBase.html#a05e6400358ec1f529a67209d3f24cc63',1,'faiss::gpu::IVFBase::resources_()']]],
  ['rotate_5fdata',['rotate_data',['../structfaiss_1_1IndexLSH.html#a71e9142e1256705f125ded9d647f4497',1,'faiss::IndexLSH']]],
  ['rrot',['rrot',['../structfaiss_1_1IndexLSH.html#a71c8aa08d3bd0483ccc0f11c22cd3cd8',1,'faiss::IndexLSH']]]
];
