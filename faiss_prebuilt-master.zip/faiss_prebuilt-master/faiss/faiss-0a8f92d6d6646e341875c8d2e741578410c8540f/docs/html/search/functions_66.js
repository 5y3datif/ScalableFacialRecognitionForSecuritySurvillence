var searchData=
[
  ['fill_5fwith_5frandom_5flinks',['fill_with_random_links',['../structfaiss_1_1HNSW.html#a26710980aaca3c1c8729e5e055a42ebe',1,'faiss::HNSW']]],
  ['find_5fduplicates',['find_duplicates',['../structfaiss_1_1IndexIVFPQ.html#aee355b57acde203a3caed46a93e16a3c',1,'faiss::IndexIVFPQ']]],
  ['fvec_5fl2sqr',['fvec_L2sqr',['../namespacefaiss.html#a7466bd32de31640860393a701eaac5ad',1,'faiss']]],
  ['fvec_5fmadd',['fvec_madd',['../namespacefaiss.html#a40328c31abd0bbba5bd95d7de951e847',1,'faiss']]],
  ['fvec_5fmadd_5fand_5fargmin',['fvec_madd_and_argmin',['../namespacefaiss.html#a9da63b8bb84460f5e8ccf8e17622cc7a',1,'faiss']]],
  ['fvec_5fnorm_5fl2sqr',['fvec_norm_L2sqr',['../namespacefaiss.html#a7a49180ebf10e643217bbce5862c7f84',1,'faiss']]],
  ['fvec_5fnorms_5fl2',['fvec_norms_L2',['../namespacefaiss.html#a40265aa2cbbe57e5b223c2c7dafac31f',1,'faiss']]],
  ['fvec_5fnorms_5fl2sqr',['fvec_norms_L2sqr',['../namespacefaiss.html#abce90e9d55d6838c7a37422285192d54',1,'faiss']]],
  ['fvecs_5fmaybe_5fsubsample',['fvecs_maybe_subsample',['../namespacefaiss.html#a14884d253128c7af5891a65082ad7dc6',1,'faiss']]]
];
