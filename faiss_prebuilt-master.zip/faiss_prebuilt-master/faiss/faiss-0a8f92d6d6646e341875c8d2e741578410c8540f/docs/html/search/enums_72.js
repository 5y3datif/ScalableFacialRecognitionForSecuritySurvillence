var searchData=
[
  ['rangestat',['RangeStat',['../structfaiss_1_1ScalarQuantizer.html#a867ad0000e4ccfd40bbb1e01e7882d06',1,'faiss::ScalarQuantizer']]]
];
