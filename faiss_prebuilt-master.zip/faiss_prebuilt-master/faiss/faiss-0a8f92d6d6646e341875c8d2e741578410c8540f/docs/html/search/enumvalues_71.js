var searchData=
[
  ['qt_5f4bit',['QT_4bit',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952eacd3d1bd71533a7bc52149e4b3d1db13b',1,'faiss::ScalarQuantizer']]],
  ['qt_5f8bit',['QT_8bit',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952ea1650389e3efa052ff60177d502328a2c',1,'faiss::ScalarQuantizer']]],
  ['qt_5f8bit_5funiform',['QT_8bit_uniform',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952ea029f07a15ea64e7e73daaf9633ac429a',1,'faiss::ScalarQuantizer']]]
];
