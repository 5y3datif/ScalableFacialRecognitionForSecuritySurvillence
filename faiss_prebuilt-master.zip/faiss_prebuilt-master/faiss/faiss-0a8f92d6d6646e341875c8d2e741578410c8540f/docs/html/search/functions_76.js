var searchData=
[
  ['vectortransform',['VectorTransform',['../structfaiss_1_1VectorTransform.html#a137f48bab695736f0b1d79a50cddc858',1,'faiss::VectorTransform']]],
  ['view',['view',['../classfaiss_1_1gpu_1_1Tensor.html#a74dbc09519c9c14479b2d18f2e5042e8',1,'faiss::gpu::Tensor::view(DataPtrType at)'],['../classfaiss_1_1gpu_1_1Tensor.html#a35a63cfa4034a8ee14a999132d8a1828',1,'faiss::gpu::Tensor::view()'],['../classfaiss_1_1gpu_1_1Tensor.html#a665d97851f0929cad7fc76f945b64c97',1,'faiss::gpu::Tensor::view(std::initializer_list&lt; IndexT &gt; sizes)'],['../classfaiss_1_1gpu_1_1detail_1_1SubTensor.html#a62aa5465abe64321c40763f74cfb028a',1,'faiss::gpu::detail::SubTensor::view()']]]
];
