var searchData=
[
  ['_7edevicetensor',['~DeviceTensor',['../classfaiss_1_1gpu_1_1DeviceTensor.html#a1ed30ec2ee0d3e7c9b8b9b93f5d2acca',1,'faiss::gpu::DeviceTensor']]],
  ['_7ehosttensor',['~HostTensor',['../classfaiss_1_1gpu_1_1HostTensor.html#ab24605e0ecd9ef9892ac33ce7d763cef',1,'faiss::gpu::HostTensor']]],
  ['_7ekerneltimer',['~KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html#af9883350bf0732b2452f1ce4670266fa',1,'faiss::gpu::KernelTimer']]],
  ['_7eworkerthread',['~WorkerThread',['../classfaiss_1_1gpu_1_1WorkerThread.html#ac1a9c44f38ea5345a650da04b032d41b',1,'faiss::gpu::WorkerThread']]]
];
