var searchData=
[
  ['kerneltimer',['KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html#af533a5a8734243263032960c2445d233',1,'faiss::gpu::KernelTimer']]],
  ['km_5fupdate_5fcentroids',['km_update_centroids',['../namespacefaiss.html#aa2c6a9e87a64bba8e8014e14f70bde21',1,'faiss']]],
  ['kmeans_5fclustering',['kmeans_clustering',['../namespacefaiss.html#a38bd0dde8a1b229201a5fcb64d05daa6',1,'faiss']]],
  ['knn_5finner_5fproduct',['knn_inner_product',['../namespacefaiss.html#a880c7318971f866267a86945aaa61b17',1,'faiss']]],
  ['knn_5fl2sqr',['knn_L2sqr',['../namespacefaiss.html#a2f803e3d3b07cfab63699c89de161237',1,'faiss']]],
  ['knn_5fl2sqr_5fbase_5fshift',['knn_L2sqr_base_shift',['../namespacefaiss.html#a5eb1701e46123827966f2a56da893d1d',1,'faiss']]]
];
