var searchData=
[
  ['q1',['q1',['../structfaiss_1_1Index2Layer.html#a5f2d70740af90b8c7ac946d58ec947aa',1,'faiss::Index2Layer']]],
  ['qt_5f4bit',['QT_4bit',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952eacd3d1bd71533a7bc52149e4b3d1db13b',1,'faiss::ScalarQuantizer']]],
  ['qt_5f8bit',['QT_8bit',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952ea1650389e3efa052ff60177d502328a2c',1,'faiss::ScalarQuantizer']]],
  ['qt_5f8bit_5funiform',['QT_8bit_uniform',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952ea029f07a15ea64e7e73daaf9633ac429a',1,'faiss::ScalarQuantizer']]],
  ['quantizer',['quantizer',['../structfaiss_1_1IndexBinaryIVF.html#a5c08ac8e6c1444e61b9f357cfba34e2e',1,'faiss::IndexBinaryIVF::quantizer()'],['../structfaiss_1_1Level1Quantizer.html#a3cf99e2ee92b8558a066f821efab95d5',1,'faiss::Level1Quantizer::quantizer()']]],
  ['quantizer_5f',['quantizer_',['../classfaiss_1_1gpu_1_1GpuIndexIVF.html#aaa7dd748e3cbd7ef68f2e384ac503eab',1,'faiss::gpu::GpuIndexIVF::quantizer_()'],['../classfaiss_1_1gpu_1_1IVFBase.html#a878114abdba07c9cf7735f9c0ed594c3',1,'faiss::gpu::IVFBase::quantizer_()']]],
  ['quantizer_5ftrains_5falone',['quantizer_trains_alone',['../structfaiss_1_1Level1Quantizer.html#a1dcea762fc322fdcffe64f78994edea0',1,'faiss::Level1Quantizer']]],
  ['quantizertype',['QuantizerType',['../structfaiss_1_1ScalarQuantizer.html#a1201dbd1611fa5c10782ade5d0e4952e',1,'faiss::ScalarQuantizer']]],
  ['query',['query',['../classfaiss_1_1gpu_1_1IVFFlat.html#a6652ca90a8a30512104fc909f0a0a6b8',1,'faiss::gpu::IVFFlat::query()'],['../classfaiss_1_1gpu_1_1IVFPQ.html#ab0c458aab9a3d903f31b0e63ce16e623',1,'faiss::gpu::IVFPQ::query()']]],
  ['queryresult',['QueryResult',['../structfaiss_1_1RangeSearchPartialResult_1_1QueryResult.html',1,'faiss::RangeSearchPartialResult']]]
];
