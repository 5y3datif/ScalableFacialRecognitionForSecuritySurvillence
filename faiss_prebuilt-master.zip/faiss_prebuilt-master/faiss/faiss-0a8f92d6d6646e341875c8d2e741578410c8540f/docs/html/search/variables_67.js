var searchData=
[
  ['gt_5fd',['gt_D',['../structfaiss_1_1AutoTuneCriterion.html#a40e91caa9232a597c16fc946d0befd9b',1,'faiss::AutoTuneCriterion']]],
  ['gt_5fi',['gt_I',['../structfaiss_1_1AutoTuneCriterion.html#af915fc4df215e3c8d9f71ff42d526144',1,'faiss::AutoTuneCriterion']]],
  ['gt_5fnnn',['gt_nnn',['../structfaiss_1_1AutoTuneCriterion.html#a9b3a2242729a0873d255c1684881bbd4',1,'faiss::AutoTuneCriterion']]]
];
