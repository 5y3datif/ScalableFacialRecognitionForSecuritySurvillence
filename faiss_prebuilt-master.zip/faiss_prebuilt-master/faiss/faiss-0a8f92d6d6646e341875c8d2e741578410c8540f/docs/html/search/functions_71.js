var searchData=
[
  ['query',['query',['../classfaiss_1_1gpu_1_1IVFFlat.html#a6652ca90a8a30512104fc909f0a0a6b8',1,'faiss::gpu::IVFFlat::query()'],['../classfaiss_1_1gpu_1_1IVFPQ.html#ab0c458aab9a3d903f31b0e63ce16e623',1,'faiss::gpu::IVFPQ::query()']]]
];
