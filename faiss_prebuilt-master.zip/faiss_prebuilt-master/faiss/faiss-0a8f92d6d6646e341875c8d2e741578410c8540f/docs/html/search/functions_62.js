var searchData=
[
  ['binary_5fto_5freal',['binary_to_real',['../namespacefaiss.html#ac8260e10cfeed08a4344b85845773e16',1,'faiss']]],
  ['bincode_5fhist',['bincode_hist',['../namespacefaiss.html#a154a47857ed321b9db91122770a16e09',1,'faiss']]]
];
